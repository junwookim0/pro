Vue.component('footer-component',{
    template : 
    `
    <div>
        <v-footer color="black" dark>
        <div class="mx-auto">Copyright &copy;</div>
        </v-footer>
    </div>
    `
    
})