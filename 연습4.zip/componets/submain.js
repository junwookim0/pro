Vue.component('sub-component',{
    template : 
    `
    <div>
    <v-img  height="600" src="./img/exhotel.jpg" aspect-ratio="1.5"></v-img>
    </div>
    `,
    data : function() {
        return {
            
    
            
        }
    }
})