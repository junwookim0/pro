Vue.component('mainp',{
    template : 
    `
    <div>
    <v-img  height="1000" src="./img/1.jpg" aspect-ratio="1.5">
    <v-row
        class="fill-height"
        align="center"
        justify="center"
        >
        <div id="carouseltext">
        
            <p class="animate__animated animate__fadeInLeft"> WE CREATE YOUR </p>
            <p class="animate__animated animate__slideInRight"> SPACE BETTER </p>
        
        </div>
        </v-row>
        </v-img>
    </div>
    `,
    data : function() {
        return {
            
    
            
        }
    }
})